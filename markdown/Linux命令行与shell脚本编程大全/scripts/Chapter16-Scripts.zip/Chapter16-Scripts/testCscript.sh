#!/bin/bash
#Demonstration script C for multiple background jobs 
#
echo "And... another Test script."
sleep 60
#
exit
