#!/bin/bash
#Demonstration script A for multiple background jobs 
#
echo "This is Test Script #1."
sleep 60
#
exit
