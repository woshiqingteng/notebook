#!/bin/bash
# testing the if statement
if pwd
then
     echo "It worked"
fi
