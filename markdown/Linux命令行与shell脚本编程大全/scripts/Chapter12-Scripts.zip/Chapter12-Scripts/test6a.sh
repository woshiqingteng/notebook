#!/bin/bash
# testing the test command
#
if test
then
     echo "No expression returns a True"
else 
     echo "No expression returns a False"
fi
