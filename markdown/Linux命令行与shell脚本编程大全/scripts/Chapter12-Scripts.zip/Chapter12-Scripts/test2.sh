#!/bin/bash
# testing an incorrect command
if IamNotaCommand
then
     echo "It worked"
fi
echo "We are outside the if statement"
