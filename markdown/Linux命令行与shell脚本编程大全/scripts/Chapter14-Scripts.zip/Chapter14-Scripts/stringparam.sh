#!/bin/bash
# Using one command-line string parameter
#
echo Hello $1, glad to meet you.
exit 
