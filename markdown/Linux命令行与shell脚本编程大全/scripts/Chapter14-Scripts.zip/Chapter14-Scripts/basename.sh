#!/bin/bash
# Handling the $0 command-line parameter
#
echo This script name is $0.
exit
