#!/bin/bash
# Testing different methods for grabbing all the parameters
#
echo
echo "Using the \$* method: $*"
echo 
echo "Using the \$@ method: $@"
echo 
exit
