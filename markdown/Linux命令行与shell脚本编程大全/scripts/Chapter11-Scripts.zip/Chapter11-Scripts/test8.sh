#!/bin/bash
var1=100
var2=45
var3=$[$var1 / $var2]
echo The final result is $var3
