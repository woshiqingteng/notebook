#!/bin/bash
testing=$(date)
echo "The date and time are: " $testing
